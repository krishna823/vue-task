import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export const store = new Vuex.Store({
  state: {
    userDetails: []
  },
  mutations: {
    SAVE_CUSTOMER(state, data) {
      this.state.userDetails.push(data)
      debugger; // eslint-disable-line
    }
  },
  actions: {
    saveCustomerData(context, data) {
      context.commit('SAVE_CUSTOMER', data)
    }
  }
})
