<template>
  <div class="contact">
    <div class="form">
      <div>
        <label>Name</label>
        <input type="text" v-model="contactObj.name">
      </div>
      <div>
        <label>Mobile</label>
        <input type="text" v-model="contactObj.mobile">
      </div>
      <div>
        <label>Email</label>
        <input type="text" v-model="contactObj.email">
      </div>
      <div>
        <label>Address</label>
        <textarea v-model="contactObj.address" rows="2"></textarea>
      </div>
      <div>
        <button type="button" @click="saveContact(contactObj)">Submit</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      contactObj: {
        name: '',
        email: '',
        mobile: '',
        address: ''
      },
    };
  },
  methods: {
    saveContact(data) {
      localStorage.setItem('contactData', JSON.stringify(data));
      this.$store.dispatch('saveCustomerData', data)
    }
  }
}
</script>

<style scoped>
.contact {
  width:400px;
  margin:auto;
  border:1px solid #ccc;
  border-radius:3px;
  padding:15px 15px 40px 15px;
  margin-top:30px;
}
.contact textarea {
  display: block;
  width: 97%;
  height: 35px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 3px;
  margin-top: 5px;
  padding-left: 10px;
}
.contact input {
  display: block;
  width: 97%;
  height: 35px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 3px;
  margin-top: 5px;
  padding-left: 10px;
}
.contact label {
  font-weight: bold;
}
.contact button {
    width: 50%;
    float: right;
    background: #2b59e2;
    color: #fff;
    font-weight: bold;
    outline: none;
    padding: 10px;
    border: none;
    border-radius: 3px;
    cursor: pointer;
}
</style>