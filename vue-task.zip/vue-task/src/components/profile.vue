<template>
  <div class="profile">
    <div class="viewContent" v-if="contentType === 'view'">
      <span class="editIcon" @click="editProfile()">Edit</span>
      <div>
        <label>Email</label>
        <div>{{displayEmai}}</div>
      </div><br>
      <div>
        <label>Mobile</label>
        <div>{{displayMobile}}</div>
      </div>
    </div>
    <div class="form" v-else>
      <div>
        <label>Email</label>
        <input type="text" v-model="profileObj.email">
      </div>
      <div>
        <label>Mobile</label>
        <input type="text" v-model="profileObj.mobile">
      </div>
      <div>
        <button type="button" @click="saveProfile(profileObj)">Save</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      displayEmai: '',
      displayMobile: '',
      profileObj: {
        email: '',
        mobile: ''
      },
      contentType: ''
    };
  },
  methods: {
    saveProfile(obj) {
      localStorage.setItem('profileData', JSON.stringify(obj));
      this.contentType = 'view'
      this.displayEmai = obj.email;
      this.displayMobile = obj.mobile;
      this.profileObj = {}
    },
    editProfile() {
      const profileData = JSON.parse(localStorage.getItem('profileData'));
      this.profileObj.email = profileData.email;
      this.profileObj.mobile = profileData.mobile;
      this.contentType = 'save'
    }
  },
}
</script>

<style scoped>
.editIcon {
  float:right;
  color: #faa74a;
  cursor: pointer;
}
.profile {
  width:400px;
  margin:auto;
  border:1px solid #ccc;
  border-radius:3px;
  padding:15px 15px 40px 15px;
  margin-top:30px;
}
.profile input {
  display: block;
  width: 97%;
  height: 35px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 3px;
  margin-top: 5px;
  padding-left: 10px;
}
.profile label {
  font-weight: bold;
}
.profile button {
    width: 50%;
    float: right;
    background: #2b59e2;
    color: #fff;
    font-weight: bold;
    outline: none;
    padding: 10px;
    border: none;
    border-radius: 3px;
    cursor: pointer;
}
</style>