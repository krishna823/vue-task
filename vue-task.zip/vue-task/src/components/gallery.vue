<template>
  <div class="gallery">
    <div class="filterImg">
      <input type="text" placeholder="Search" @input="filterImage" v-model="searchImg">
    </div>
    <ul>
      <li v-for="(img, index) in flowers" :key="index">
        <img :src="img.image">
        <label>{{img.title}}</label>
      </li>
    </ul>
  </div>
</template>


<script>
export default {
  data () {
    return {
      searchImg: '',
      flowersList: [
        { image: 'https://florgeous.com/wp-content/uploads/2019/10/orange-abutilon.jpg', title: 'Abutilon' },
        { image: 'https://florgeous.com/wp-content/uploads/2019/10/acacia-white.jpg', title: 'Acacia' },
        { image: 'https://florgeous.com/wp-content/uploads/2019/10/yellow-aconite.jpg', title: 'Aconite' },
        { image: 'https://florgeous.com/wp-content/uploads/2019/10/balloon-flower.jpg', title: 'Brassica' },
        { image: 'https://florgeous.com/wp-content/uploads/2019/10/ballota.jpg', title: 'Ballota' },
        { image: 'https://florgeous.com/wp-content/uploads/2019/10/bee-balm.jpg', title: 'Borage' },
        { image: 'https://florgeous.com/wp-content/uploads/2019/10/calendula.jpg', title: 'Calendula' },
        { image: 'https://florgeous.com/wp-content/uploads/2019/10/california-poppy.jpg', title: 'Candytuft' },
        { image: 'https://florgeous.com/wp-content/uploads/2019/09/camellia-japonica.jpg', title: 'Camellia' },
        { image: 'https://florgeous.com/wp-content/uploads/2019/10/tawny-daylily.jpg', title: 'Daylily' },
        { image: 'https://florgeous.com/wp-content/uploads/2019/10/euphorbia-milii.jpg', title: 'Euphorbia' }
      ],
      flowers: []
    };
  },
  created() {
    this.flowers = this.flowersList
  },
  methods: {
    filterImage(e) {
      const flowers = this.flowersList
      if (e.target.value.length > 0) {
        this.flowers = []
        flowers.forEach((item) => {
          const itemName = item.title.toLowerCase()
          const searchName = e.target.value.toLowerCase()
          const checkValue = itemName.includes(searchName)
          if (checkValue) {
            this.flowers.push(item)
          }
        })
      } else {
        this.flowers = this.flowersList
      }
    }
  },
}
</script>

<style scoped>
.gallery ul {
  width: 90%;
  margin: auto;
  margin-top:40px;
}
.gallery ul li {
  width: 30%;
  margin: auto;
  display: inline;
  float: left;
}
.gallery ul li img {
  width: 290px;
}
.gallery label {
  display: block;
  margin-bottom: 30px;
}
.filterImg input {
  display: block;
  width: 50%;
  height: 35px;
  margin: auto;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 3px;
  margin-top: 25px;
  padding-left: 10px;
}
</style>