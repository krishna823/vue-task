<template>
  <div class="task">
    <div class="header">
      <ul>
        <li @click="clickTab('profile')">Profile</li>
        <li @click="clickTab('gallery')">Gallery</li>
        <li @click="clickTab('contact')">Contact</li>
      </ul>
    </div>
    <profile v-if="tabTitle === 'profile'"></profile>
    <gallery v-if="tabTitle === 'gallery'"></gallery>
    <contact v-if="tabTitle === 'contact'"></contact>
  </div>
</template>

<script>
import profile from './profile'
import gallery from './gallery'
import contact from './contact'

export default {
  components: {
    'profile': profile,
    'gallery': gallery,
    'contact': contact
  },
  data () {
    return {
      tabTitle: 'profile'
    };
  },
  methods: {
    clickTab(value) {
      this.tabTitle = value
    }
  },
  props: {
    msg: String
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
body{
  margin: 0 !important;
  font-family: arial;
}
.header {
  height: 60px;
  background: #8e5ba6;
  color: #fff;
}
.header ul{
  width:500px;
  margin: auto;
}
.header li {
  padding: 10px;
  font-weight: bold;
  font-size: 18px;
  width: 100px;
  margin-top: 10px;
  cursor: pointer;
  text-align: center;
}
.header li:hover {
  background: #8347a0;
}
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
